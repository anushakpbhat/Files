/*Arrow functions*/
let name = (name = "Anu") => console.log(name);
name("Sha");

/*Template Strings*/
let firstName = "Anu";
let lastName = "sha";
console.log(`The name is:${firstName}${lastName}`);
