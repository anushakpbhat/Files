/*Interface example1*/
interface Student {
  firstName: string;
  lastName: string;
  rollNo: number;
  marksScored: number;
}

let details: Student = {
  firstName: "Raj",
  lastName: "Sarja",
  rollNo: 12,
  marksScored: 85
};
console.log(details);

/*Interface example2*/
interface Employee {
  firstName: string;
  lastName: string;
  employeeId: number;
  location: string;
  available: boolean;
}

let documents: Employee = {
  firstName: "Anusha",
  lastName: "KP",
  employeeId: 5731,
  location: "Mysore",
  available: true
};
console.log(documents);
