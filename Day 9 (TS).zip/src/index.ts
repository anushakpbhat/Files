let sum = (a: number, b: number): number => {
  return a + b;
};
console.log(sum(5, 10));

var result = (firstName: string, lastName: string): string => {
  return `${firstName}${lastName}`;
};
console.log(result("anu", "sha"));
