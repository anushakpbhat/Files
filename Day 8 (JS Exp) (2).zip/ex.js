/*var,const*/
var neww = 100;
function changeName() {
  if (true) {
    var neww = 300;
    console.log(neww);
  }

  if (true) {
    const neww = 35;
    console.log(neww);
  }
}
changeName();
console.log(neww);

/*let*/
let name = function () {
  if (true) {
    let num = 100;
    console.log(num);
    num++;
    console.log(num);
  }
};
name();
